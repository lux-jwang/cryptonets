/* config.h.  Generated from config.h.in by configure.  */
#define ENABLE_INTRIN 1
#define ENABLE___BUILTIN_CLZLL 1
#define ENABLE__ADDCARRY_U64 1
#define ENABLE__SUBBORROW_U64 1
#define ENABLE__MULX_U64 1
